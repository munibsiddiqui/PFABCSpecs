//
//  NiceLogger.h
//  NiceLogger
//
//  Created by Zhihui Tang on 2017-10-14.
//  Copyright © 2017 Crafttang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NiceLogger.
FOUNDATION_EXPORT double NiceLoggerVersionNumber;

//! Project version string for NiceLogger.
FOUNDATION_EXPORT const unsigned char NiceLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLogger/PublicHeader.h>


